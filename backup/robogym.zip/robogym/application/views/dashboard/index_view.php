<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="container">Hello from dashboard...</div>
