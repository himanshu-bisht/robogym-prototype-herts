<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name='RoboGym' content='Welcome to RoboGym!'>
	<mera name='Author' content='RoboGym'>
	<title> Welcome to the Homepage of RoboGym</title>
	<link rel="stylesheet" href="assets/statics/bootstrap/css/bootstrap.min.css">
  <script src='assets/statics/bootstrap/js/bootstrap.min.js'></script>
	<link rel="stylesheet" href="<?php echo base_url('assets/statics/bootstrap/css/style.css');?>">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo base_url('https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css');?>"
	 <!-- integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
	crossorigin="anonymous"> -->
	<script src="<?php echo base_url('https://code.jquery.com/jquery-3.3.1.slim.min.js');?>"
	integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
	 crossorigin="anonymous"></script>
	<script src="<?php echo base_url('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js');?>"
	integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
	 crossorigin="anonymous"></script>
  <script src="<?php echo base_url('https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js');?>"
	integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
	crossorigin="anonymous"></script>
	<link rel="stylesheet" href="<?php echo base_url('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');?>"

</head>
<body>
<!--- footer------>
<section id="footer">
  <div class="container">
    <p allign='text-center'><i class="fa fa-cogs" aria-hidden="true"></i>  Powered By by team blue </p>
  </div>
</section>
<!--footer end-------->
<body>
</html>
